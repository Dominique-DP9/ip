package kleebot.ui;

public class KleeExceptions extends Exception {
    public KleeExceptions(String m) {
        super(m);
    }
}
